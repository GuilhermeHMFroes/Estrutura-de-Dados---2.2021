import plotly.express as px
import csv

def grafico1(dx, dy, tt, h, w):
    fig = px.bar(x=dx, y=dy, title = f"{tt}", height=h, width=w) # Height : Altura; Width : Largura
    fig.show()

def grafico2(dx, dy, tt, h, w):
    fig = px.pie(names = dx, values = dy, title = f"{tt}", width = w, height = h)
    fig.show()

def total(tabela):
    ''' Tabela
    1 = tabela confirmados
    2 = tabela internados
    3 = tabela óbitos
    4 = tabela recuperados
    '''

    # Confirmados
    if(tabela == 1):
        tab = open('Planilhas/CONFIRMADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        ncc = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:

            numcasos = i[1]
            a = i[2]
            data = a[3:]

            if (numcasos != "NUM_CASOS" and data != 'DATA'):
                casoconv = int(numcasos)

                ncc.append(casoconv)
                dc.append(data)

        tcc = 0  # total de casos confirmados

        for i in ncc:
            tcc = tcc + i

        title = f'CASOS CONFIRMADOS EM MG: {tcc}'

    # Internados
    if (tabela == 2):
        tab = open('Planilhas/INTERNADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        ncc = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:

            numcasos = i[1]
            a = i[2]
            data = a[3:]

            if (numcasos != "NUM_INTERNADOS" and data != 'DATA'):
                casoconv = int(numcasos)

                ncc.append(casoconv)
                dc.append(data)

        tcc = 0  # total de casos confirmados

        for i in ncc:
            tcc = tcc + i

        title = f'INTERNADOS EM MG: {tcc}'

    # Óbitos
    if (tabela == 3):
        tab = open('Planilhas/OBITOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        ncc = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:

            numcasos = i[1]
            a = i[2]
            data = a[3:]

            if (numcasos != "NUM_OBITOS" and data != 'DATA'):
                casoconv = int(numcasos)

                ncc.append(casoconv)
                dc.append(data)

        tcc = 0  # total de casos confirmados

        for i in ncc:
            tcc = tcc + i

        title = f'ÓBITOS EM MG: {tcc}'

    # Recuperados
    if (tabela == 4):
        tab = open('Planilhas/RECUPERADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        ncc = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:

            numcasos = i[1]
            a = i[2]
            data = a[3:]

            if (numcasos != "NUM_RECUPERADOS" and data != 'DATA'):
                casoconv = int(numcasos)

                ncc.append(casoconv)
                dc.append(data)

        tcc = 0  # total de casos confirmados

        for i in ncc:
            tcc = tcc + i

        title = f'RECUPERADOS EM MG: {tcc}'

    grafico2(dc, ncc, title, 800, 800)

def buscaCidade(tabela, ce):
    ''' Tabela
    1 = tabela confirmados
    2 = tabela internados
    3 = tabela Óbitos
    4 = tabela recuperados
    '''

    # Confirmados
    if(tabela == 1):
        tab = open('Planilhas/CONFIRMADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    # Internados
    if (tabela == 2):
        tab = open('Planilhas/INTERNADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    # Óbitos
    if (tabela == 3):
        tab = open('Planilhas/OBITOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    # Recuperados
    if (tabela == 4):
        tab = open('Planilhas/RECUPERADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    n1 = []  # Números de casos Confirmados
    dc = []  # Data Casos

    for i in tab_reader:
        cidade = i[0]

        if (ce == cidade):
            numcasos = i[1]
            a = i[2]
            data = a[3:]

            casoconv = int(numcasos)

            n1.append(casoconv)
            dc.append(data)

            tcc = 0
            for i in n1:
                tcc = tcc + 1

    # Confirmados
    if (tabela == 1):
        title = f'{ce}: {tcc} confirmados'

    # Internados
    if(tabela == 2):
        title = f'{ce}: {tcc} internados ao todo'

    # Óbitos
    if (tabela == 3):
        title = f'{ce}: {tcc} óbitos'

    # Recuperados
    if (tabela == 4):
        title = f'{ce}: {tcc} recuperados'

    grafico2(dc, n1, title, 800, 800)

def buscamacro(tabela, me):
    ''' Tabela
    1 = tabela confirmados
    2 = tabela internados
    3 = tabela Óbitos
    4 = tabela recuperados
    '''

    # Confirmados
    if (tabela == 1):
        tab = open('Planilhas/CONFIRMADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            macro = i[6]

            if (me == macro):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

        tcc = 0
        for i in n1:
            tcc = tcc + i

        title = f'Macro: {me}({tcc} casos confirmados)'

    # Internados
    if (tabela == 2):
        tab = open('Planilhas/INTERNADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            macro = i[6]

            if (me == macro):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

        tcc = 0
        for i in n1:
            tcc = tcc + i

        title = f'Macro: {me}({tcc} internados)'

    # Óbitos
    if (tabela == 3):
        tab = open('Planilhas/OBITOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            macro = i[6]

            if (me == macro):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

        tcc = 0
        for i in n1:
            tcc = tcc + i

        title = f'Macro: {me}({tcc} óbitos)'

    # Recuperados
    if (tabela == 4):
        tab = open('Planilhas/RECUPERADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            macro = i[6]

            if (me == macro):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

        tcc = 0
        for i in n1:
            tcc = tcc + i

        title = f'Macro: {me}({tcc} recuperados'

    grafico2(dc, n1, title, 800, 800)

def cidades(tabela):
    ''' Tabela
    1 = tabela confirmados
    2 = tabela internados
    3 = tabela óbitos
    4 = tabela recuperados
    '''

    if (tabela == 1):
        tab = open('Planilhas/CONFIRMADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    if (tabela == 2):
        tab = open('Planilhas/INTERNADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    if (tabela == 3):
        tab = open('Planilhas/OBITOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    if (tabela == 4):
        tab = open('Planilhas/RECUPERADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    print('\nCidades: ')

    cidades = []

    c = 0

    for i in tab_reader:
        cidade = i[0]
        rp = 0

        if (cidade != 'MUNICIPIO_RESIDENCIA'):
            if (c == 0):
                cidades.append(cidade)
                c = 1

            if (c > 0):
                for j in cidades:
                    if (j == cidade):
                        rp = 1

                if (rp == 0):
                    cidades.append(cidade)

    a1 = 0
    for i in cidades:
        print(f'\t{a1} - {i}')
        a1 = a1 + 1

    procura = int(input('\nDigite o número referente a cidade: '))

    ce = cidades[procura]

    if(tabela == 1):
        print(f'Gerando o gráfico de casos confirmados na cidade de {ce}')

    if (tabela == 2):
        print(f'Gerando o gráfico de internados na cidade de {ce}')

    if (tabela == 3):
        print(f'Gerando o gráfico de óbitos na cidade de {ce}')

    if (tabela == 4):
        print(f'Gerando o gráfico de recuperados na cidade de {ce}')

    buscaCidade(tabela, ce)

def microa(tabela):
    ''' Tabela
    1 = tabela confirmados
    2 = tabela internados
    3 = tabela óbitos
    4 = tabela recuperados
    '''

    if(tabela == 1):
        tab = open('Planilhas/CONFIRMADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    if(tabela == 2):
        tab = open('Planilhas/INTERNADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    if(tabela == 3):
        tab = open('Planilhas/OBITOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    if(tabela == 4):
        tab = open('Planilhas/RECUPERADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

    print('\nMicro Região')

    micros = []

    m = 0

    for i in tab_reader:
        micro = i[5]
        rp = 0

        if (micro != 'Micro'):
            if (m == 0):
                micros.append(micro)
                m = 1

            if (m > 0):
                for j in micros:
                    if (j == micro):
                        rp = 1

                if (rp == 0):
                    micros.append(micro)

    a1 = 0
    for i in micros:
        print(f'\t{a1} - {i}')
        a1 = a1 + 1

    procura = int(input('\nDigite o número referente a micro: '))

    me = micros[procura]

    # Confirmados
    if (tabela == 1):
        tab = open('Planilhas/CONFIRMADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        print(f'Gerando o gráfico de casos confirmados da micro {me}')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            cidade = i[0]

            if (me == cidade):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

                tcc = 0
                for i in n1:
                    tcc = tcc + 1

                title = f'Micro: {me}({tcc} casos confirmados)'

    # Internados
    if (tabela == 2):
        tab = open('Planilhas/INTERNADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        print(f'Gerando o gráfico de internados da micro {me}')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            cidade = i[0]

            if (me == cidade):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

                tcc = 0
                for i in n1:
                    tcc = tcc + 1

                title = f'Micro: {me}({tcc} internados)'

    # Óbitos
    if (tabela == 3):
        tab = open('Planilhas/OBITOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        print(f'Gerando o gráfico de óbitos da micro {me}')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            cidade = i[0]

            if (me == cidade):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

                tcc = 0
                for i in n1:
                    tcc = tcc + 1

                title = f'Micro: {me}({tcc} óbitos)'

    # Recuperados
    if (tabela == 4):
        tab = open('Planilhas/RECUPERADOS.csv', 'r')
        tab_reader = csv.reader(tab, delimiter=';')

        print(f'Gerando o gráfico de recuperados da micro {me}')

        n1 = []  # Números de casos Confirmados
        dc = []  # Data Casos

        for i in tab_reader:
            cidade = i[0]

            if (me == cidade):
                numcasos = i[1]
                a = i[2]
                data = a[3:]

                casoconv = int(numcasos)

                n1.append(casoconv)
                dc.append(data)

                tcc = 0
                for i in n1:
                    tcc = tcc + 1

                title = f'Micro: {me}({tcc} recuperados0'

    grafico2(dc, n1, title, 800, 800)

def confirmados():
    tab = open('Planilhas/CONFIRMADOS.csv', 'r')
    tab_reader = csv.reader(tab, delimiter=';')
    tab = 1

    while 1:
        print('=' * 50)
        print('\t\t\t\tCASOS CONFIRMADOS')
        print('=' * 50)

        print('\n')
        i = 1
        print(f'{i} - Total de casos confirmados')
        i = i + 1
        print(f'{i} - Casos confirmados por cidade')
        i = i + 1
        print(f'{i} - Casos confirmados por micro região')
        i = i + 1
        print(f'{i} - Casos confirmados por macro região')

        print(f'{0} - Sair')
        # i = i + 1
        # print(f'{i} - ')

        opc = int(input('\nOpção: '))

        if (opc == 0):
            break

        # N total
        if(opc == 1):
            print('\nGerando o gráfico do total de casos confirmados.\n')
            total(tab)
            break

        # Cidades
        if (opc == 2):
            cidades(tab)
            break

        # Micro Região
        if(opc == 3):
            microa(tab)
            break

        # Macro Região
        if (opc == 4):
            print('\nMacro Região')

            micros = []

            m = 0

            for i in tab_reader:
                micro = i[6]
                rp = 0

                if (micro != 'Macro'):
                    if (m == 0):
                        micros.append(micro)
                        m = 1

                    if (m > 0):
                        for j in micros:
                            if (j == micro):
                                rp = 1

                        if (rp == 0):
                                    micros.append(micro)

            a1 = 0
            for i in micros:
                print(f'\t{a1} - {i}')
                a1 = a1 + 1

            procura = int(input('\nDigite o número referente a macro: '))

            me = micros[procura]

            print(f'Gerando o gráfico de casos confirmados da macro {me}')

            buscamacro(1, me)

            break

def internados():
    tab = open('Planilhas/INTERNADOS.csv', 'r')
    tab_reader = csv.reader(tab, delimiter=';')

    tab = 2

    while 1:
        print('=' * 50)
        print('\t\t\t\tINTERNADOS')
        print('=' * 50)

        print('\n')
        i = 1
        print(f'{i} - Total de internados')
        i = i + 1
        print(f'{i} - Internados por cidade')
        i = i + 1
        print(f'{i} - Internados por micro região')
        i = i + 1
        print(f'{i} - Internados por macro região')

        print(f'{0} - Sair')
        # i = i + 1
        # print(f'{i} - ')

        opc = int(input('\nOpção: '))

        if (opc == 0):
            break

        # N total
        if (opc == 1):
            print('\nGerando o gráfico do total de internados.\n')
            total(tab)
            break

        # Cidades
        if (opc == 2):
            cidades(tab)
            break

        # Micro Região
        if (opc == 3):
            microa(tab)
            break

        # Macro Região
        if (opc == 4):
            print('\nMacro Região')

            micros = []

            m = 0

            for i in tab_reader:
                micro = i[6]
                rp = 0

                if (micro != 'Macro'):
                    if (m == 0):
                        micros.append(micro)
                        m = 1

                    if (m > 0):
                        for j in micros:
                            if (j == micro):
                                rp = 1

                        if (rp == 0):
                            micros.append(micro)

            a1 = 0
            for i in micros:
                print(f'\t{a1} - {i}')
                a1 = a1 + 1

            procura = int(input('\nDigite o número referente a macro: '))

            me = micros[procura]

            print(f'Gerando o gráfico de casos confirmados da macro {me}')

            buscamacro(1, me)

            break

def obitos():
    tab = open('Planilhas/OBITOS.csv', 'r')
    tab_reader = csv.reader(tab, delimiter=';')
    tab = 3

    while 1:
        print('=' * 50)
        print('\t\t\t\tÓBITOS')
        print('=' * 50)

        print('\n')
        i = 1
        print(f'{i} - Total de óbitos')
        i = i + 1
        print(f'{i} - Óbitos por cidade')
        i = i + 1
        print(f'{i} - Óbitos por micro região')
        i = i + 1
        print(f'{i} - Óbitos por macro região')

        print(f'{0} - Sair')
        # i = i + 1
        # print(f'{i} - ')

        opc = int(input('\nOpção: '))

        if (opc == 0):
            break

        # N total
        if(opc == 1):
            print('\nGerando o gráfico do total de óbitos.\n')
            total(tab)
            break

        # Cidades
        if (opc == 2):
            cidades(tab)
            break

        # Micro Região
        if(opc == 3):
            microa(tab)
            break

        # Macro Região
        if (opc == 4):
            print('\nMacro Região')

            micros = []

            m = 0

            for i in tab_reader:
                micro = i[6]
                rp = 0

                if (micro != 'Macro'):
                    if (m == 0):
                        micros.append(micro)
                        m = 1

                    if (m > 0):
                        for j in micros:
                            if (j == micro):
                                rp = 1

                        if (rp == 0):
                            micros.append(micro)

            a1 = 0
            for i in micros:
                print(f'\t{a1} - {i}')
                a1 = a1 + 1

            procura = int(input('\nDigite o número referente a macro: '))

            me = micros[procura]

            print(f'Gerando o gráfico de casos confirmados da macro {me}')

            buscamacro(1, me)

            break

def recuperados():
    tab = open('Planilhas/OBITOS.csv', 'r')
    tab_reader = csv.reader(tab, delimiter=';')
    tab = 4

    while 1:
        print('=' * 50)
        print('\t\t\t\tRECUPERADOS')
        print('=' * 50)

        print('\n')
        i = 1
        print(f'{i} - Total de recuperados')
        i = i + 1
        print(f'{i} - Recuperados por cidade')
        i = i + 1
        print(f'{i} - Recuperados por micro região')
        i = i + 1
        print(f'{i} - Recuperados por macro região')

        print(f'{0} - Sair')
        # i = i + 1
        # print(f'{i} - ')

        opc = int(input('\nOpção: '))

        if (opc == 0):
            break

        # N total
        if(opc == 1):
            print('\nGerando o gráfico do total de recuperados.\n')
            total(tab)
            break

        # Cidades
        if (opc == 2):
            cidades(tab)
            break

        # Micro Região
        if(opc == 3):
            microa(tab)
            break

        # Macro Região
        if (opc == 4):
            print('\nMacro Região')

            micros = []

            m = 0

            for i in tab_reader:
                micro = i[6]
                rp = 0

                if (micro != 'Macro'):
                    if (m == 0):
                        micros.append(micro)
                        m = 1

                    if (m > 0):
                        for j in micros:
                            if (j == micro):
                                rp = 1

                        if (rp == 0):
                            micros.append(micro)

            a1 = 0
            for i in micros:
                print(f'\t{a1} - {i}')
                a1 = a1 + 1

            procura = int(input('\nDigite o número referente a macro: '))

            me = micros[procura]

            print(f'Gerando o gráfico de casos confirmados da macro {me}')

            buscamacro(1, me)

            break

if __name__ == '__main__':

    while 1:
        print('\n')
        print('='*50)
        print('\t\t\t\t\tMENU')
        print('=' * 50)

        print('\n')
        i = 1
        print(f'{i} - Casos Confirmados')
        i = i + 1
        print(f'{i} - Internados')
        i = i + 1
        print(f'{i} - Óbitos')
        i = i + 1
        print(f'{i} - Recuperados')

        print(f'{0} - Finalizar Programa')
        #i = i + 1
        #print(f'{i} - ')

        opc = int(input('\nOpção: '))

        if (opc == 0):
            print('=' * 50)
            break

        if(opc == 1):
            confirmados()

        if (opc == 2):
            internados()

        if (opc == 3):
            obitos()

        if (opc == 4):
            recuperados()
